async function fetchJSON(url){ const res = await fetch(url); return res.json(); }

async function renderCart(){
  const data = await fetchJSON('/api/cart');
  const el = document.getElementById('cart');
  if (!data.items.length) { el.innerHTML = '<p>Cart is empty</p>'; return; }
  let html = '<div>';
  let total = 0;
  data.items.forEach(it=>{
    const line = (it.product.price*it.quantity).toLocaleString('en-IN', {style:'currency', currency:'INR'});
    html += `<div class="card"><h3>${it.product.name}</h3><p>Qty: ${it.quantity}</p><p>${line}</p></div>`;
    total += it.product.price*it.quantity;
  });
  html += `<p><strong>Total: ${(total).toLocaleString('en-IN', {style:'currency', currency:'INR'})}</strong></p>`;
  html += '<button id="checkout" class="btn">Checkout</button>';
  el.innerHTML = html + '</div>';
  document.getElementById('checkout').addEventListener('click', async ()=>{
    const res = await fetch('/api/orders', {method:'POST'});
    const j = await res.json();
    if (j.ok) { alert('Order placed: '+j.orderId); window.location='/'; }
    else alert(j.error || 'Failed');
  });
}

renderCart();
