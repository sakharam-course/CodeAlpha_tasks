async function fetchJSON(url){ const res = await fetch(url); return res.json(); }

async function renderProducts(){
  const products = await fetchJSON('/api/products');
  const container = document.getElementById('products');
  container.innerHTML = '';
  products.forEach(p=>{
    const el = document.createElement('div'); el.className='card';
    el.innerHTML = `
      <img src="${p.image || '/assets/img/placeholder.svg'}" alt="${p.name}">
      <h3>${p.name}</h3>
      <p>${(p.price).toLocaleString('en-IN', {style: 'currency', currency: 'INR'})}</p>
      <a class="btn" href="/product.html?id=${p.id}">View</a>
      <button class="btn" data-id="${p.id}">Add</button>
    `;
    container.appendChild(el);
  });
  document.querySelectorAll('.card button[data-id]').forEach(btn=>{
    btn.addEventListener('click', async ()=>{
      const id = btn.getAttribute('data-id');
      await fetch('/api/cart/add', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({productId:id,quantity:1})});
      alert('Added to cart');
    });
  });
}

async function renderProductDetail(){
  const qs = new URLSearchParams(location.search);
  const id = qs.get('id');
  if (!id) { document.getElementById('product').innerText='No product id'; return; }
  const p = await fetchJSON('/api/products/'+id);
  const el = document.getElementById('product');
  el.innerHTML = `
    <div class="card">
      <img src="${p.image || '/assets/img/placeholder.svg'}">
      <h2>${p.name}</h2>
      <p>${p.description}</p>
      <p><strong>${(p.price).toLocaleString('en-IN', {style: 'currency', currency: 'INR'})}</strong></p>
      <button id="addBtn" class="btn">Add to cart</button>
    </div>
  `;
  document.getElementById('addBtn').addEventListener('click', async ()=>{
    await fetch('/api/cart/add', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({productId:id,quantity:1})});
    alert('Added to cart');
  });
}

if (document.getElementById('products')) renderProducts();
if (document.getElementById('product')) renderProductDetail();
