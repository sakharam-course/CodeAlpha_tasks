# Simple E-commerce Demo

Minimal e-commerce site with Express.js and SQLite.

Quick start

1. Install dependencies

```bash
npm install
```

2. Start the server

```bash
npm start
```

3. Open http://localhost:3000

Notes

- Uses an on-disk SQLite DB at `data/ecommerce.db`.
- Sessions are stored in memory (development-only).
- Change `server.js` session secret for production.
