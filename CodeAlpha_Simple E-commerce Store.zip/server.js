const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const session = require('express-session');
const path = require('path');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: 'replace-this-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24*60*60*1000 }
}));

const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'ecommerce.db');

const fs = require('fs');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new sqlite3.Database(DB_FILE);

function runAsync(sql, params=[]) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) reject(err); else resolve(this);
    });
  });
}
function allAsync(sql, params=[]) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err); else resolve(rows);
    });
  });
}
function getAsync(sql, params=[]) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err); else resolve(row);
    });
  });
}

async function initDB() {
  await runAsync(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT)`);
  await runAsync(`CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY, name TEXT, description TEXT, price REAL, image TEXT)`);
  await runAsync(`CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, user_id INTEGER, total REAL, created_at TEXT)`);
  await runAsync(`CREATE TABLE IF NOT EXISTS order_items (id INTEGER PRIMARY KEY, order_id INTEGER, product_id INTEGER, quantity INTEGER, price REAL)`);

  const row = await getAsync(`SELECT COUNT(*) as cnt FROM products`);
  if (!row || row.cnt === 0) {
    const sample = [
      ['Red T-Shirt', 'Comfortable cotton t-shirt', 799.00, '/assets/img/red-shirt.svg'],
      ['Blue Jeans', 'Classic straight fit jeans', 1999.00, '/assets/img/blue-jeans.svg'],
      ['Sneakers', 'Lightweight running shoes', 3499.00, '/assets/img/sneakers.svg']
    ];
    for (const p of sample) {
      await runAsync(`INSERT INTO products (name,description,price,image) VALUES (?,?,?,?)`, p);
    }
    console.log('Seeded products');
  }
  // Ensure existing products use local images (map by name)
  const mappings = [
    ['Red T-Shirt','/assets/img/red-shirt.svg'],
    ['Blue Jeans','/assets/img/blue-jeans.svg'],
    ['Sneakers','/assets/img/sneakers.svg']
  ];
  for (const m of mappings) {
    await runAsync(`UPDATE products SET image = ? WHERE name = ? AND (image IS NULL OR image = '' OR image LIKE '%placeholder%' OR image LIKE '%.svg' OR image LIKE 'https:%')`, m);
  }

  // Ensure additional products exist (upsert by name)
  async function ensureProduct(name, description, price, image){
    const existing = await getAsync(`SELECT id FROM products WHERE name = ?`, [name]);
    if (!existing) {
      await runAsync(`INSERT INTO products (name,description,price,image) VALUES (?,?,?,?)`, [name, description, price, image]);
    } else {
      await runAsync(`UPDATE products SET description = ?, price = ?, image = ? WHERE id = ?`, [description, price, image, existing.id]);
    }
  }

  await ensureProduct('Black Hoodie','Warm and comfy hoodie',1299.00,'/assets/img/black-hoodie.svg');
  await ensureProduct('Cap','Classic baseball cap',299.00,'/assets/img/cap.svg');
  await ensureProduct('Sunglasses','UV-protection sunglasses',899.00,'/assets/img/sunglasses.svg');
  await ensureProduct('Leather Belt','Genuine leather belt',599.00,'/assets/img/leather-belt.svg');
  await ensureProduct('Wrist Watch','Stylish analog wrist watch',4999.00,'/assets/img/wrist-watch.svg');
  await ensureProduct('Backpack','Durable everyday backpack',2199.00,'/assets/img/backpack.svg');
}

initDB().catch(err=>console.error('DB init error', err));

// Serve frontend
app.use('/', express.static(path.join(__dirname, 'public')));
app.use('/assets', express.static(path.join(__dirname, 'public','assets')));

// Auth
app.post('/api/register', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Missing fields' });
  const hash = bcrypt.hashSync(password, 10);
  try {
    await runAsync(`INSERT INTO users (username,password) VALUES (?,?)`, [username, hash]);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: 'Username taken' });
  }
});

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await getAsync(`SELECT * FROM users WHERE username = ?`, [username]);
  if (!user) return res.status(401).json({ error: 'Invalid' });
  const ok = bcrypt.compareSync(password, user.password);
  if (!ok) return res.status(401).json({ error: 'Invalid' });
  req.session.user = { id: user.id, username: user.username };
  res.json({ ok: true, user: req.session.user });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(err => { res.json({ ok: true }); });
});

app.get('/api/me', (req, res) => {
  res.json({ user: req.session.user || null });
});

// Products
app.get('/api/products', async (req, res) => {
  const rows = await allAsync(`SELECT * FROM products`);
  res.json(rows);
});
app.get('/api/products/:id', async (req, res) => {
  const row = await getAsync(`SELECT * FROM products WHERE id = ?`, [req.params.id]);
  if (!row) return res.status(404).json({ error: 'Not found' });
  res.json(row);
});

// Cart stored in session
app.get('/api/cart', async (req, res) => {
  const cart = req.session.cart || {};
  const items = [];
  for (const pid in cart) {
    const p = await getAsync(`SELECT * FROM products WHERE id = ?`, [pid]);
    if (p) items.push({ product: p, quantity: cart[pid] });
  }
  res.json({ items });
});
app.post('/api/cart/add', (req, res) => {
  const { productId, quantity } = req.body;
  if (!req.session.cart) req.session.cart = {};
  const q = parseInt(quantity) || 1;
  req.session.cart[productId] = (req.session.cart[productId] || 0) + q;
  res.json({ ok: true, cart: req.session.cart });
});
app.post('/api/cart/clear', (req, res) => {
  req.session.cart = {};
  res.json({ ok: true });
});

// Orders
app.post('/api/orders', async (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: 'Login required' });
  const cart = req.session.cart || {};
  const items = [];
  let total = 0;
  for (const pid in cart) {
    const p = await getAsync(`SELECT * FROM products WHERE id = ?`, [pid]);
    if (p) {
      items.push({ product: p, quantity: cart[pid] });
      total += p.price * cart[pid];
    }
  }
  if (items.length === 0) return res.status(400).json({ error: 'Cart empty' });

  const createdAt = new Date().toISOString();
  const r = await runAsync(`INSERT INTO orders (user_id,total,created_at) VALUES (?,?,?)`, [req.session.user.id, total, createdAt]);
  const orderId = r.lastID;
  for (const it of items) {
    await runAsync(`INSERT INTO order_items (order_id,product_id,quantity,price) VALUES (?,?,?,?)`, [orderId, it.product.id, it.quantity, it.product.price]);
  }
  req.session.cart = {};
  res.json({ ok: true, orderId });
});

app.get('/api/orders', async (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: 'Login required' });
  const orders = await allAsync(`SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC`, [req.session.user.id]);
  res.json(orders);
});

app.get('/api/orders/:id', async (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: 'Login required' });
  const order = await getAsync(`SELECT * FROM orders WHERE id = ? AND user_id = ?`, [req.params.id, req.session.user.id]);
  if (!order) return res.status(404).json({ error: 'Not found' });
  const items = await allAsync(`SELECT oi.*, p.name FROM order_items oi JOIN products p ON p.id = oi.product_id WHERE oi.order_id = ?`, [req.params.id]);
  res.json({ order, items });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
