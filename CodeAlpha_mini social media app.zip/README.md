Mini Social — Demo
===================

Quick demo of a mini social media app (Express backend + single-file frontend).

Run locally:

1. Install dependencies

```bash
npm install
```

2. Start server

```bash
npm start
```

3. Open browser

```
http://localhost:3000/
```

Notes:
- Data is persisted in `data.db` (SQLite). Restarting the server preserves data.
- Endpoints: `GET/POST /api/users`, `POST /api/follow`, `GET/POST /api/posts`, `POST /api/posts/:id/comments`, `POST /api/posts/:id/like`.

Files created:
- `public/index.html`, `public/styles.css`, `public/app.js` (frontend)
- `server.js` (Express + SQLite server)
- `data.db` will be created automatically on first run

