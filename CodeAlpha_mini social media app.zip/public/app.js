const api = (path, opts)=>fetch(path,opts).then(r=>r.json())

function avatarHtml(name){
  const initials = (name||'').split(' ').map(s=>s[0]||'').slice(0,2).join('').toUpperCase()
  return `<div class="avatar">${initials}</div>`
}

async function loadUsers(){
  const users = await api('/api/users')
  const sel = document.getElementById('userSelect')
  sel.innerHTML = ''
  users.forEach(u=>{
    const o = document.createElement('option')
    o.value = u.id
    o.textContent = u.name
    sel.appendChild(o)
  })
  renderProfiles(users)
}

function renderProfiles(users){
  const out = document.getElementById('profilesList')
  out.innerHTML = ''
  users.forEach(u=>{
    const div = document.createElement('div')
    div.className = 'item'
    div.innerHTML = `<div style="display:flex;align-items:center;gap:12px;width:100%">
        ${avatarHtml(u.name)}
        <div style="flex:1">
          <div style="font-weight:600">${u.name}</div>
          <div class="muted" style="font-size:13px">${u.bio||''}</div>
        </div>
        <div style="display:flex;flex-direction:column;gap:6px">
          <button class="btn ghost" data-follow="${u.id}">${u.followers>0? 'Following' : 'Follow'}</button>
          <div class="muted" style="text-align:right;font-size:12px">${u.followers} followers</div>
        </div>
      </div>`
    out.appendChild(div)
  })

  out.querySelectorAll('button[data-follow]').forEach(btn=>btn.addEventListener('click',async e=>{
    const followeeId = btn.getAttribute('data-follow')
    const followerId = document.getElementById('userSelect').value
    await api('/api/follow',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({followerId,followeeId})})
    await loadUsers(); loadPosts();
  }))
}

async function loadPosts(){
  const posts = await api('/api/posts')
  const container = document.getElementById('posts')
  container.innerHTML = ''
  posts.slice().reverse().forEach(p=>{
    const el = document.createElement('div')
    el.className = 'card post'
    const liked = p.likes.includes(document.getElementById('userSelect').value)
    el.innerHTML = `
      <div class="meta">
        <div style="display:flex;align-items:center;gap:12px">
          ${avatarHtml(p.authorName)}
          <div>
            <div style="font-weight:700">${p.authorName}</div>
            <div class="muted">${new Date(p.createdAt).toLocaleString()}</div>
          </div>
        </div>
        <div class="muted">Likes: ${p.likes.length} · Comments: ${p.comments.length}</div>
      </div>
      <div class="content">${escapeHtml(p.content)}</div>
      <div class="engage">
        <button class="icon-btn" data-like="${p.id}"><span class="heart ${liked? 'liked':''}">♥</span><span class="muted">Like</span></button>
        <button class="icon-btn" data-comment="${p.id}">💬 <span class="muted">Comment</span></button>
      </div>
      <div style="margin-top:8px" data-comments-for="${p.id}"></div>
    `
    container.appendChild(el)
  })

  document.querySelectorAll('button[data-like]').forEach(b=>b.addEventListener('click',async e=>{
    const postId = b.getAttribute('data-like')
    const userId = document.getElementById('userSelect').value
    await api(`/api/posts/${postId}/like`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({userId})})
    loadPosts()
  }))

  document.querySelectorAll('button[data-comment]').forEach(b=>b.addEventListener('click',async e=>{
    const postId = b.getAttribute('data-comment')
    const posts = await api('/api/posts')
    const post = posts.find(p=>p.id==postId)
    openCommentModal(postId, post.authorName)
  }))
}

function escapeHtml(s){ return (s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])) }

function openCommentModal(postId, authorName){
  const modal = document.getElementById('commentModal')
  modal.classList.add('open')
  document.getElementById('commentFor').textContent = `Replying to ${authorName}`
  document.getElementById('commentText').value = ''
  modal.dataset.postId = postId
}
function closeCommentModal(){ document.getElementById('commentModal').classList.remove('open') }

document.getElementById('closeModal').addEventListener('click', closeCommentModal)
document.getElementById('sendComment').addEventListener('click', async ()=>{
  const postId = document.getElementById('commentModal').dataset.postId
  const content = document.getElementById('commentText').value
  const userId = document.getElementById('userSelect').value
  if(!content) return alert('Enter a comment')
  await api(`/api/posts/${postId}/comments`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({userId,content})})
  closeCommentModal(); loadPosts()
})

const postArea = document.getElementById('postContent')
const charCount = document.getElementById('charCount')
postArea.addEventListener('input', ()=>{ charCount.textContent = `${postArea.value.length}/280` })
document.getElementById('emojiBtn').addEventListener('click', ()=>{ postArea.value += '😊'; postArea.dispatchEvent(new Event('input')) })

document.getElementById('createUserBtn').addEventListener('click', async ()=>{
  const name = document.getElementById('nameInput').value.trim()
  const bio = document.getElementById('bioInput').value.trim()
  if(!name) return alert('Enter a name')
  await api('/api/users',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name,bio})})
  document.getElementById('nameInput').value=''; document.getElementById('bioInput').value=''
  await loadUsers(); loadPosts()
})

document.getElementById('createPostBtn').addEventListener('click', async ()=>{
  const content = document.getElementById('postContent').value.trim()
  const userId = document.getElementById('userSelect').value
  if(!content) return alert('Write something')
  await api('/api/posts',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({userId,content})})
  document.getElementById('postContent').value=''; postArea.dispatchEvent(new Event('input'))
  loadPosts()
})

(async ()=>{ await loadUsers(); await loadPosts(); })()
