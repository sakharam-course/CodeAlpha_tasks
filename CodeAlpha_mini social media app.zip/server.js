const express = require('express')
const cors = require('cors')
const bodyParser = require('body-parser')
const path = require('path')
const low = require('lowdb')
const FileSync = require('lowdb/adapters/FileSync')

const app = express()
app.use(cors())
app.use(bodyParser.json())

// Serve static frontend from public/
app.use(express.static(path.join(__dirname, 'public')))

// Initialize lowdb (JSON file)
const adapter = new FileSync(path.join(__dirname, 'db.json'))
const db = low(adapter)
db.defaults({users:[],followers:[],posts:[],comments:[],likes:[]}).write()

function genId(){ return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}` }

app.get('/api/users', (req,res)=>{
  const users = db.get('users').value()
  const followers = db.get('followers').value()
  const out = users.map(u=>({id:u.id,name:u.name,bio:u.bio,followers: followers.filter(f=>f.followeeId===u.id).length}))
  res.json(out)
})

app.post('/api/users', (req,res)=>{
  const {name,bio} = req.body||{}
  if(!name) return res.status(400).json({error:'name required'})
  const id = genId()
  db.get('users').push({id,name,bio:bio||''}).write()
  res.json({id,name,bio:bio||'',followers:0})
})

app.post('/api/follow', (req,res)=>{
  const {followerId, followeeId} = req.body||{}
  if(!followerId || !followeeId) return res.status(400).json({error:'invalid ids'})
  const exists = db.get('followers').find({followerId,followeeId}).value()
  if(!exists) db.get('followers').push({id:genId(),followerId,followeeId}).write()
  res.json({ok:true})
})

app.get('/api/posts', (req,res)=>{
  const posts = db.get('posts').value()
  const users = db.get('users').value()
  const likes = db.get('likes').value()
  const comments = db.get('comments').value()
  const out = posts.map(p=>{
    const author = users.find(u=>u.id===p.authorId) || {name:'Unknown'}
    const postLikes = likes.filter(l=>l.postId===p.id).map(l=>l.userId)
    const postComments = comments.filter(c=>c.postId===p.id).map(c=>({id:c.id,authorId:c.authorId,authorName:(users.find(u=>u.id===c.authorId)||{}).name,content:c.content,createdAt:c.createdAt}))
    return {id:p.id,authorId:p.authorId,authorName:author.name,content:p.content,createdAt:p.createdAt,likes:postLikes,comments:postComments}
  })
  res.json(out)
})

app.post('/api/posts', (req,res)=>{
  const {userId:uid,content} = req.body||{}
  if(!uid) return res.status(400).json({error:'invalid user'})
  const id = genId()
  const createdAt = Date.now()
  db.get('posts').push({id,authorId:uid,content:content||'',createdAt}).write()
  const user = db.get('users').find({id:uid}).value() || {name:'Unknown'}
  res.json({id,authorId:uid,authorName:user.name,content:content||'',createdAt,likes:[],comments:[]})
})

app.post('/api/posts/:id/comments', (req,res)=>{
  const pid = req.params.id
  const {userId:uid,content} = req.body||{}
  if(!uid || !content) return res.status(400).json({error:'invalid'})
  const id = genId()
  const createdAt = Date.now()
  db.get('comments').push({id,postId:pid,authorId:uid,content,createdAt}).write()
  const user = db.get('users').find({id:uid}).value() || {name:'Unknown'}
  res.json({id,postId:pid,authorId:uid,authorName:user.name,content,createdAt})
})

app.post('/api/posts/:id/like', (req,res)=>{
  const pid = req.params.id
  const {userId:uid} = req.body||{}
  if(!uid) return res.status(400).json({error:'invalid user'})
  const existing = db.get('likes').find({postId:pid,userId:uid}).value()
  if(existing) db.get('likes').remove({id:existing.id}).write()
  else db.get('likes').push({id:genId(),postId:pid,userId:uid}).write()
  const likes = db.get('likes').filter({postId:pid}).map('userId').value()
  res.json({likes})
})

const PORT = process.env.PORT || 3000
app.listen(PORT, ()=>console.log(`Mini social server running on http://localhost:${PORT}`))
